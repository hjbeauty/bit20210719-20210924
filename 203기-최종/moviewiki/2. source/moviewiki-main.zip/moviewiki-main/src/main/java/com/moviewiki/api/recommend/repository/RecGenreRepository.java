//package com.moviewiki.api.recommend.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public class RecGenreRepository extends JpaRepository<RecGenre, Integer> {
//
//    public List<RecGenre> selectAllJPQL();
//}
