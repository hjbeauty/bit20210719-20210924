package com.moviewiki.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviewikiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoviewikiApplication.class, args);
  }

}
