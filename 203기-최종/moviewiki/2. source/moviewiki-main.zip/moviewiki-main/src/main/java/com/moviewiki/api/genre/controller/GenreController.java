package com.moviewiki.api.genre.controller;

import org.springframework.stereotype.Controller;

@Controller
public class GenreController {

}
