package com.myturn.bit.controll;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.myturn.bit.model.service.MemberService;
import com.myturn.bit.model.vo.MemberVO;

@Controller
@RequestMapping("/member")
public class MemberController {
	private static final Logger logger = LoggerFactory.getLogger(MemberController.class); 
	
	@Inject 
	MemberService memberService;
	
	@RequestMapping("home")
	public void home() {
		
	}
	
	@RequestMapping("list")
	public String memberList(Model model) {
		System.out.println("리스트 불러오기");
		List<MemberVO> list = memberService.memberList();
		model.addAttribute("list", list);
		System.out.println("리스트 불러오기2");
		return "member/memberList";
		
	}
	
	@RequestMapping("join")
	public String joinStart() {
		return "/member/joinSite";
	}
	
	@PostMapping("joinSite")
	public String siteJoin(@ModelAttribute MemberVO mVo) {
		System.out.println("joinsite process");
		memberService.joinSite(mVo);
		System.out.println("member등록");
		return "redirect:/club/index";
	}
	
	 
	@RequestMapping("login")
	public String login(){
		return "member/login";
	}
	
	
	@PostMapping("loginCheck")
	public ModelAndView loginCheck(@ModelAttribute MemberVO mVo, HttpSession session){
		System.out.println("lllleeeeleee");
		boolean result = memberService.loginCheck(mVo, session);
		ModelAndView mav = new ModelAndView();
		if (result == true) {
			mav.setViewName("redirect:/club/index2");
//			mav.addObject("msg", "success");
		} else {
			mav.setViewName("/member/login");
			mav.addObject("msg", "failure");
		}
		return mav;
	}
	
	// 03. 로그아웃 처리
	@RequestMapping("logout")
	public ModelAndView logout(HttpSession session){
		memberService.logout(session);
		ModelAndView mav = new ModelAndView();
		mav.setViewName("member/login");
		mav.addObject("msg", "logout");
		return mav;
	}
	

}
