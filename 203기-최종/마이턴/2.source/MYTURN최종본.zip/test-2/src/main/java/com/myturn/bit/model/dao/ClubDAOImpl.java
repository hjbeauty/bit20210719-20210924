package com.myturn.bit.model.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.myturn.bit.model.vo.ClubMemberVO;
import com.myturn.bit.model.vo.ClubVO;

@Repository
public class ClubDAOImpl implements ClubDAO {
	
	@Inject
	SqlSession sqlSession;
	
	@Override
	public List<ClubVO> clubList() {
		
		return sqlSession.selectList("club.clubList");
	}

	@Override
	public void createClub(ClubVO cVo) {
		sqlSession.insert("club.createClub", cVo);
		
	}

	@Override
	public ClubVO viewClub(String clubName) {
	
		return sqlSession.selectOne("club.viewClub", clubName);
		
	}

	@Override
	public void deleteClub(String clubId) {
		sqlSession.delete("club.deleteClub", clubId);
		
	}

	@Override
	public void updateClub(ClubVO cVo) {
		sqlSession.update("club.updateClub", cVo);
		
	}

	@Override
	public boolean checkPw(String clubId, String clubPw) {
		boolean result = false;
		Map<String, String> map = new HashMap<String, String>();
		map.put("clubId", clubId);
		map.put("clubPw", clubPw);
		int count = sqlSession.selectOne("club.checkPw", map);
		if(count == 1) {
			result = true;
		}
		return result;
	}

	@Override
	public void joinClub(ClubMemberVO memVo) {
		sqlSession.insert("club.joinClub", memVo);
		
	}

	@Override 
	public List<ClubVO> searchClub(String searchOption, String keyword) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("searchOption", searchOption);
		map.put("keyword", keyword);
		return sqlSession.selectList("club.searchClub", map);
	}

	@Override
	public int countClub(String searchOption, String keyword) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("searchOption", searchOption);
		map.put("keyword", keyword);
		return sqlSession.selectOne("club.countClub", map);
	}
	

}
