package com.myturn.bit.model.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.myturn.bit.model.vo.ClubMemberVO;
import com.myturn.bit.model.vo.ClubVO;

public interface ClubDAO {
	
	public List<ClubVO> clubList();
	
	public void joinClub(ClubMemberVO memVo);
	
	public void createClub(ClubVO cVo);
	
	public ClubVO viewClub(String clubName);
	
	public void deleteClub(String clubId);
	
	public void updateClub(ClubVO cVo);
	
	public boolean checkPw(String clubId, String clubPw);
	
	public List<ClubVO> searchClub(String searchOption, String keyword);
	
	public int countClub(String searchOption, String keyword);
}	
