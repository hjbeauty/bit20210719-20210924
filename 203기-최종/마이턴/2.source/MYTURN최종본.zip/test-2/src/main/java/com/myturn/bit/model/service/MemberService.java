package com.myturn.bit.model.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.myturn.bit.model.vo.MemberVO;

public interface MemberService {
	public void joinSite(MemberVO mVo);
	
	public List<MemberVO> memberList();
	
	public boolean loginCheck(MemberVO mVo, HttpSession session);
	
	public void logout(HttpSession session);
	
	public MemberVO viewMember(MemberVO mVo);
	

}
