package com.myturn.bit.model.vo;

import lombok.Data;

@Data
public class ClubMemberVO {
	private String userId;
	private String clubId;
	private String selfIntroduce;
}
