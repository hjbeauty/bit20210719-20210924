package com.myturn.bit.model.vo;



import lombok.Data;

@Data
public class ClubVO {
	private String userId;
	private String clubId;
	private String clubPw;
	private String clubName;
	private String clubShortIntro;
	private String clubDetailIntro;
	private String clubKeyword;
	private String categoryCode;
	private String categoryName;
	private int totalMember;
	private int currentMember;
	
}
