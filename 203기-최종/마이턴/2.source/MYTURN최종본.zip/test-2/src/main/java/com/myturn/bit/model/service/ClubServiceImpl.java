package com.myturn.bit.model.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.myturn.bit.model.dao.ClubDAOImpl;
import com.myturn.bit.model.vo.ClubMemberVO;
import com.myturn.bit.model.vo.ClubVO;

@Service
public class ClubServiceImpl implements ClubService {
	
	@Inject
	ClubDAOImpl clubDao;
	
	@Override
	public List<ClubVO> clubList() {
		
		return clubDao.clubList();
	}

	@Override
	public void createClub(ClubVO cVo) {
		clubDao.createClub(cVo);
		
	}

	@Override
	public ClubVO viewClub(String clubName) {
		System.out.println("123412341234");
		return clubDao.viewClub(clubName);
	}

	@Override
	public void deleteClub(String clubId) {
		clubDao.deleteClub(clubId);
		
	}

	@Override
	public void updateClub(ClubVO cVo) {
		clubDao.updateClub(cVo);
		
	}

	@Override
	public boolean checkPw(String clubId, String clubPw) {
		return clubDao.checkPw(clubId, clubPw);
	}

	@Override
	public void joinClub(ClubMemberVO memVo) {
		clubDao.joinClub(memVo);
		
	}

	@Override
	public List<ClubVO> searchClub(String searchOption, String keyword) {
		
		return clubDao.searchClub(searchOption, keyword);
	}

	@Override
	public int countClub(String searchOption, String keyword) {
		
		return clubDao.countClub(searchOption, keyword);
	}

}
