package com.myturn.bit.controll;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.myturn.bit.model.dao.ClubDAO;
import com.myturn.bit.model.dao.ClubDAOImpl;
import com.myturn.bit.model.service.ClubService;
import com.myturn.bit.model.vo.ClubMemberVO;
import com.myturn.bit.model.vo.ClubVO;

import ch.qos.logback.core.recovery.ResilientSyslogOutputStream;

@Controller
@RequestMapping("/club")
public class ClubController {

		private static final Logger logger = LoggerFactory.getLogger(ClubController.class); 
	
		@Inject
		ClubService clubService;
		
		@RequestMapping("index2")
		public void start2() {
			
		}
		
		@RequestMapping("index")
		public void start() {
			
		}
		
		@RequestMapping("list")
		public String clubList(Model model) {
			List<ClubVO> list = clubService.clubList();
			model.addAttribute("list", list);
			return "/club/listClub";
		}
		
		@RequestMapping("join")
		public String joinStart() {
			
			return "/club/joinClub";
		}
		
		@PostMapping("joinClub")
		public String clubJoin(ClubMemberVO memVo) {
			System.out.println("joinClub process");
			clubService.joinClub(memVo);
			System.out.println("멤버등록 완료");
			return "redirect:/club/list";
		}
	

		@RequestMapping("/")
		public String createStart(){
			
			return "/club/createClub";
		}
		

		@RequestMapping("createClub")
		public String clubCreate(@ModelAttribute ClubVO cVo){
			clubService.createClub(cVo);
			return "redirect:/club/list";
		}
		

		@RequestMapping("view")
		public String clubView(String clubName, Model model){
	
			model.addAttribute("vo", clubService.viewClub(clubName));
			return "/club/viewClub";
		}
		
		@RequestMapping("update")
		public String clubUpdate(@ModelAttribute ClubVO cVo, Model model) {
			
			boolean result = clubService.checkPw(cVo.getClubId(), cVo.getClubPw());
			if(result) {
				clubService.updateClub(cVo);
				return "redirect:/club/list";
			}else {
//				ClubVO cVo2 = clubService.viewClub(cVo.getClubId());
//				cVo.setShortIntro(cVo2.getShortIntro());
//				cVo.setDetailIntro(cVo2.getDetailIntro());
				model.addAttribute("vo", cVo);
				model.addAttribute("message", "비밀번호가 맞지 않습니다.");
				return "club/viewClub";
			}
//			
//			clubService.updateClub(cVo);
//			return "redirect:/club/list.do";
		}
		@RequestMapping("delete")
		public String clubDelete(@ModelAttribute ClubVO cVo, @RequestParam String clubId, @RequestParam String clubPw, Model model) {
			boolean result = clubService.checkPw(clubId, clubPw);
			if(result) {
				clubService.deleteClub(clubId);
				return "redirect:/club/list";
			}else {
				model.addAttribute("vo", cVo);
				model.addAttribute("message", "비밀번호가 맞지 않습니다.");
//				model.addAttribute("vo", clubService.viewClub(clubId));
				return "club/viewClub";
			}
		}
		
		@RequestMapping("search") //검색기능, 
		public ModelAndView clubSearch(@RequestParam(defaultValue="clubName") String searchOption, @RequestParam(defaultValue="") String keyword) {
			
//			System.out.println(searchOption+keyword);
			List<ClubVO> list = clubService.searchClub(searchOption, keyword);
			
//			for(ClubVO cVo : list) {
//				System.out.println(cVo);
//			}
			
			
			int count = clubService.countClub(searchOption, keyword);
			
			ModelAndView mav = new ModelAndView();
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("list", list);
			map.put("count", count);
			map.put("searchOption", searchOption);
			map.put("keyword", keyword);
			mav.addObject("map", map);
			mav.setViewName("/club/searchClub");
//			System.out.println("검색1234");
			return mav;
			
		}
}
