package com.myturn.bit.model.service;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import com.myturn.bit.model.dao.MemberDAOImpl;
import com.myturn.bit.model.vo.MemberVO;

@Service
public class MemberServiceImpl implements MemberService{
	
	@Inject
	MemberDAOImpl memberDao;
		
	@Override
	public void joinSite(MemberVO mVo) {
		System.out.println("서비스임플");
		memberDao.joinSite(mVo);
	}

	@Override
	public List<MemberVO> memberList() {
		// TODO Auto-generated method stub
		return memberDao.memberList();
	}



	@Override
	public boolean loginCheck(MemberVO mVo, HttpSession session) {
		boolean result = memberDao.loginCheck(mVo);
		if(result) {
			MemberVO mVo2 = viewMember(mVo);
			session.setAttribute("userId", mVo2.getUserId());
			session.setAttribute("userName", mVo2.getUserName());
		}
		return result;
	}

	@Override
	public void logout(HttpSession session) {
		// TODO Auto-generated method stub
		session.invalidate();
	}

	@Override
	public MemberVO viewMember(MemberVO mVo) {
		
		return memberDao.viewMember(mVo);
	}



}
