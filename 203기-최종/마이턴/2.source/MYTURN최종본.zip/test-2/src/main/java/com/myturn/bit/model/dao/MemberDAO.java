package com.myturn.bit.model.dao;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.myturn.bit.model.vo.MemberVO;

public interface MemberDAO {
	public void joinSite(MemberVO mVo);
	public List<MemberVO> memberList();
	
	public boolean loginCheck(MemberVO mVo);
	public void logout(HttpSession session);
	public MemberVO viewMember(MemberVO mVo);
	

}
