package com.myturn.bit.model.dao;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.myturn.bit.model.vo.MemberVO;


@Repository
public class MemberDAOImpl implements MemberDAO{
	
	@Inject
	SqlSession sqlSession;

	@Override
	public void joinSite(MemberVO mVo) {
		System.out.println("다오임플");
		sqlSession.insert("member.joinSite", mVo);
		
	}

	@Override
	public List<MemberVO> memberList() {
		
		return sqlSession.selectList("member.memberList");
	}



	@Override
	public boolean loginCheck(MemberVO mVo) {
		String name = sqlSession.selectOne("member.loginCheck", mVo);
		return (name == null) ? false : true;
	}

	@Override
	public void logout(HttpSession session) {
		
		
	}

	@Override
	public MemberVO viewMember(MemberVO mVo) {
		
		return sqlSession.selectOne("member.viewMember", mVo);
	}


	

}
