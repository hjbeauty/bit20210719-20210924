package com.myturn.bit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
