package com.eat.vo;

import lombok.Data;

@Data
public class RandomVO {
	private Long id;
	private Long recipeId;
	private Long eateryId;
	
}
