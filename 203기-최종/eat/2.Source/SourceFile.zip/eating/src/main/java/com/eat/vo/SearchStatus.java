package com.eat.vo;

public enum SearchStatus {
    TAG, NAME, INGREDIENT
}
