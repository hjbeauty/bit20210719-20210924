package com.eat.vo;

import lombok.Data;

@Data
public class RecipeBookmarkVO {
   private Long id;
   private Long memberId;
   private Long recipeId;
   
}
