package com.eat.vo;

import lombok.Data;

@Data
public class RecipeTagVO {

    private Long id;
    private String name;
    private Long recipeId;

}
