package com.eat.vo;

import lombok.Data;

@Data
public class CategoryVO {
	private Long id;
	private String name;
}
