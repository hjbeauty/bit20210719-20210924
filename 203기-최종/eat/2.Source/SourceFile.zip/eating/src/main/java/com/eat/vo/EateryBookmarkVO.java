package com.eat.vo;

import lombok.Data;

@Data
public class EateryBookmarkVO {
   private Long id;
   private Long memberId;
   private Long eateryId;
   
}
