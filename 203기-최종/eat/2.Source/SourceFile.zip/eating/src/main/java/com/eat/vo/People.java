package com.eat.vo;

public enum People {
    ONE, TWO, FAMILY, PARTY
}
