package com.eat.web;

import com.eat.vo.Area;

public class EateryForm {

    private String name;
    private String content;
    private String address;
    private String phoneNumber;
    private String category;
    private Area area;
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getContent() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getAddress() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getPhoneNumber() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getCategory() {
		// TODO Auto-generated method stub
		return null;
	}
	public Area getArea() {
		// TODO Auto-generated method stub
		return null;
	}
   
}

